



public class Edge{

	private Vertex source;
	private Vertex dest;
	private double weight;

	public Edge(Vertex src, Vertex dst, double wght){
		
		source = src;
		dest = dst;
		weight = wght;
	}

	public Vertex getSource(){return source;}
	public Vertex getDest(){return dest;}
	public double getWeight(){return weight;}
	public boolean equals(Edge e){
		return (e.getSource().equals(source) && e.getDest().equals(dest)&& weight == e.getWeight() );	
	}
}
