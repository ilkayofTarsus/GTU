import java.util.*;
import java.io.*;


public class CSE222GRAPH{
	
	private ArrayList<List<Edge>> edges;
	private CSE222MAP map;
	
	public CSE222GRAPH(CSE222MAP map){
		this.map = map;
		edges = new ArrayList<List<Edge>>();
		for(int a = 0; a < map.getNumV(); a++){
			edges.add(new LinkedList<Edge>());
		}
		
		createEdges();	
	}

	public void insert(Edge e){
		edges.get(e.getSource().getLabel()).add(e);
	
	}
	
	public void createEdges(){
		for(int a = 0; a < map.getNumV(); a++){
				adjVertexes(map.getVertexes().get(a));
		}
	}
	public void adjVertexes(Vertex v){

		for(Vertex v2 : map.getVertexes()){
			if(v.getX()-1 == v2.getX() && v.getY()+1 == v2.getY()){
				insert(new Edge(v,v2,1.41));
				insert(new Edge(v2,v,1.41));
			}
			if(v.getX() == v2.getX() && v.getY()+1 == v2.getY()){
				insert(new Edge(v,v2,1));
				insert(new Edge(v2,v,1));	
			}
			if(v.getX()+1 == v2.getX() && v.getY() == v2.getY()){
				insert(new Edge(v,v2,1));
				insert(new Edge(v2,v,1));
			}
			if(v.getX()+1 == v2.getX() && v.getY()+1 == v2.getY()){
				insert(new Edge(v,v2,1.41));
				insert(new Edge(v2,v,1.41));
			}
		
		}
	}
	public double isEdge(Vertex v,Vertex s){
		List<Edge> ed = new LinkedList<Edge>();		
		ed = edges.get(v.getLabel());
		for(Edge e : ed)
			if(e.getDest().equals(s)) 
				return e.getWeight();
		
		return 999999;
	}
	
	public HashSet<Vertex> findAdj(Vertex v){
		
		HashSet<Vertex> ret = new HashSet<Vertex>();
		boolean kontrol = true;
		List<Edge> ed = new LinkedList<Edge>();		
		ed = edges.get(v.getLabel());
		for(Edge e: ed) ret.add(e.getDest());
	
		return ret;
		
	}
	public CSE222MAP getMap(){return map;}
	public ArrayList<List<Edge>> getEdges(){return edges;}
}
