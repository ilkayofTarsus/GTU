


public class Vertex{

	private int y;
	private int x;
	private int label;
	
	public Vertex(int a, int b, int c){
		
		y = a;
		x = b;
		label = c;
	}
	public Vertex(int a, int b){
		
		y = a;
		x = b;
	}
	
	public boolean equals(Vertex v){return (v.getX() == x && v.getY() == y);}
	public int getX(){return x;}
	public int getY(){return y;}
	public int getLabel(){return label;}
	public void setLabel(int a){label = a;}
	
}
