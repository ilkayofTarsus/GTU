import java.util.*;
import java.io.*;


public class CSE222DIJKSTRA{

	private CSE222GRAPH graph;
	private Set<Vertex> S;
	private Set<Vertex> VS;
	private double[] d;
	private int[] p;
	public double length;
	
	public CSE222DIJKSTRA (CSE222GRAPH gr){
		graph = gr;
		S = new HashSet<Vertex>();
		VS = new HashSet<Vertex>();
		d = new double[gr.getMap().getVertexes().size()];
		p = new int[gr.getMap().getVertexes().size()];	
		length = 999999;
		/*long startTime = System.currentTimeMillis();
		long endTime = System.currentTimeMillis();
		long total = endTime - startTime;
		System.out.printf("\ndijk hız = " + total/1000 + "\n");
	*/
	}
	public void fillVS(){
		for(int a = 0 ; a <graph.getMap().getVertexes().size();a++)
			if(!graph.getMap().getVertexes().get(a).equals(graph.getMap().getStarting())) 
				VS.add(graph.getMap().getVertexes().get(a));
	
	}
	public ArrayList<Vertex> Dijkstra()throws Exception{
		
		S.add(graph.getMap().getStarting());		
		fillVS();
		Vertex s = (Vertex)S.toArray()[0];
		for(Vertex v : VS){
			p[v.getLabel()] = s.getLabel();
			d[v.getLabel()] = graph.isEdge(s,v);
		}		
		double smallest = 999999;
		Vertex aranan = new Vertex(-1,-1);
		
		while(!VS.isEmpty()){
			smallest = 999999;
			for(Vertex v1 : VS){
				if(d[v1.getLabel()] <= smallest){
					aranan = v1;
					smallest = d[v1.getLabel()];
				}
				
			}
			VS.remove(aranan);
			S.add(aranan);
			Set<Vertex> adj = graph.findAdj(aranan);
			for(Vertex v2 : adj){
				double w = graph.isEdge(v2,aranan);
				if(d[aranan.getLabel()] + w < d[v2.getLabel()]){
					d[v2.getLabel()] = d[aranan.getLabel()] + w;
					p[v2.getLabel()] = aranan.getLabel();
				}
			}
		}
		ArrayList<Vertex> ret = new ArrayList<Vertex>();
		int index = graph.getMap().getEnding().getLabel();
		for(int a = 0; a < p.length; a++){
			Vertex v = graph.getMap().getVertexes().get(p[index]);
			ret.add(v);
			index = p[index];
			if(v.equals(graph.getMap().getStarting())) break;
		}
		
		length =  d[graph.getMap().getEnding().getLabel()];
		if(d[graph.getMap().getEnding().getLabel()] == 999999) throw new Exception("can not find a path");
			
		return ret;
			
	}
}
