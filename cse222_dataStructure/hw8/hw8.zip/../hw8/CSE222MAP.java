import java.util.*;
import java.io.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public class CSE222MAP{
	
	private Vertex startingPoint;
	private Vertex endingPoint;
	private String[][] map;
	private ArrayList<Vertex> vertexes;
	private int numV;
	
	public CSE222MAP(Scanner scan, int Y, int X)throws Exception{
		
		String[] st = scan.nextLine().split(",");
		startingPoint = new Vertex(Integer.parseInt(st[0]),Integer.parseInt(st[1]));
		st = scan.nextLine().split(",");
		endingPoint = new Vertex(Integer.parseInt(st[0]),Integer.parseInt(st[1])) ;	
		map = new String[Y][X];
		vertexes = new ArrayList<Vertex>();
		numV = fillMap(scan);
		if(map[startingPoint.getY()][startingPoint.getX()].equals("1")) throw new Exception("starting point 1!!!");
		if(map[endingPoint.getY()][endingPoint.getX()].equals("1")) throw new Exception("ending point 1!!!");
	/*
				File file = new File("ilkay.txt");
				if (!file.exists()) {
				file.createNewFile();
				}

				FileWriter fileWriter = new FileWriter(file, false);
				BufferedWriter bWriter = new BufferedWriter(fileWriter);
				for(int a=0; a<500; a++){
				for(int b=0; b<500; b++){
					bWriter.write(map[a][b]);
				}bWriter.write("\n");}
				bWriter.close();*/
	}
	
	public void toPng(String nm, String type)throws Exception{
		String pngFilePath =  "pngMaps/" + type + "Maps/" + nm + ".png";
		int width = map[0].length; 
		int height = map.length; 
		    BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		    for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
			    String pixelChar = map[y][x];
			    int color = (pixelChar.equals("1")) ? 0xFFFFA500 : 0xFFFFFFFF; 
			    image.setRGB(x, y, color);
			}
		    }

		    ImageIO.write(image, "png", new File(pngFilePath));
	}
		
	public void drawLine(ArrayList<Vertex> line,String nm, String type)throws Exception{
	
		String imageFile = "pngMaps/" + type + "Maps/" + nm + ".png";
		int colorRGB = 0xFFAA0000; 
		for(Vertex v : line){
		    BufferedImage image = ImageIO.read(new File(imageFile));
		    image.setRGB(v.getX(), v.getY(), colorRGB);
		    ImageIO.write(image, "PNG", new File(imageFile));
		}
	}
		
		
	public int fillMap(Scanner scan)throws Exception{
		int sayac = 0,sayac3 = 0 ;
		String st;
		String[] st2;
		while(scan.hasNext()){
			st = scan.nextLine();
			st2 = st.split(",");
			for(int a = 0; a < st2.length; a++){
				
				map[sayac][a] = st2[a];
				if(st2[a].equals("0")){
					Vertex nVert = new Vertex(sayac,a,sayac3);
					vertexes.add(nVert);
					sayac3++;
					if(startingPoint.equals(nVert)) startingPoint = nVert;
					if(endingPoint.equals(nVert)) endingPoint = nVert;
				}

			}
			sayac++;
		}
		
		return sayac3;
			
	}
	
	public void writePath(List<Vertex> path,String type,String mp)throws Exception{
		File file = new File("paths/" + type +"/" + mp + "Path.txt");
		if (!file.exists()) {
			file.createNewFile();
		}

		FileWriter fileWriter = new FileWriter(file, false);
		BufferedWriter bWriter = new BufferedWriter(fileWriter);
		for(Vertex v: path){
			bWriter.write(v.getY() + "," + v.getX() + "\n");
		}
		bWriter.close();
	
	}

	public Vertex getStarting(){ return startingPoint;}
	public Vertex getEnding(){ return endingPoint;}
	public ArrayList<Vertex> getVertexes(){ return vertexes;}
	public String[][] getMap(){ return map;}
	public int getNumV(){ return numV;}

}
